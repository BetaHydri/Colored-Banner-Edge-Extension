// Background service worker
chrome.runtime.onInstalled.addListener(() => {
  console.log('Red Browser - Production App extension installed');
});
